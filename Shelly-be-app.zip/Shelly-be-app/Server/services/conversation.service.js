
const { fileRead } = require('../utils/conversation.util.js')

const getAllConversations = ((req, res) => {
    const id = req.params.customerId;
    const conversations = fileRead(id);
    res.send(conversations);
})

module.exports = {
    getAllConversations
};