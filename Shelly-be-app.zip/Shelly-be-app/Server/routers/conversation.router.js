const { Router } = require('express');
const { getConversations } = require('../controllers/conversation.controller.js')

const app = Router();
app.get('/:customerId', getConversations);
module.exports = app;