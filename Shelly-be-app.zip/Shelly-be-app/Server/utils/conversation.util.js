const fs = require('fs');
const dataPath = './database/conversations.json'

const fileRead = (id) => {
    const jsonData = fs.readFileSync(dataPath)
    return JSON.parse(jsonData)    
}

module.exports = {
    fileRead
};