
const { getAllConversations } = require("../services/conversation.service.js")

const getConversations = ((req, res) => {
    try {
        const conversations = getAllConversations(req, res);
        res.send(conversations)
    } catch (error) {
        console.info(`Error in handleTalk ${error}`);
    }
})

module.exports = {
    getConversations
};